import React from 'react'
import Navbar from './navbar/Navbar'
import News from './news/News'


const App = () => {
  return (
    <React.Fragment>
      <Navbar/>
      <News />
    
      
    </React.Fragment>
  )
}

export default App;
